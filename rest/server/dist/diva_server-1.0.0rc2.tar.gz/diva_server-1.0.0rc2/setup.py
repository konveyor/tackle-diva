# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['diva_server',
 'diva_server.business_logic',
 'diva_server.postprocess',
 'diva_server.spec']

package_data = \
{'': ['*']}

install_requires = \
['Flask-Cors>=3.0.10,<4.0.0',
 'PyYAML>=5.4.1,<6.0.0',
 'aiohttp-jinja2>=1.4.2,<2.0.0',
 'aiohttp>=3.7.4,<4.0.0',
 'connexion[swagger-ui]>=2.9.0,<3.0.0',
 'docker>=5.0.0,<6.0.0',
 'environs>=9.3.3,<10.0.0',
 'importlib-metadata>=4.6.4,<5.0.0',
 'pytest>=6.2.4,<7.0.0',
 'requests>=2.26.0,<3.0.0']

setup_kwargs = {
    'name': 'diva-server',
    'version': '1.0.0rc2',
    'description': 'Server logic for DiVA REST service',
    'long_description': None,
    'author': 'Shin Saito',
    'author_email': 'shinsa@jp.ibm.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7.0,<3.8.0',
}


setup(**setup_kwargs)
